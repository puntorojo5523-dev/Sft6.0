# PuntoRojo Manager

Aplicación Android nativa inicial para administrar clientes PPPoE de PuntoRojo.

## Estado de esta entrega (0.1.0)
- Panel principal con resumen.
- Listado de clientes de demostración.
- Alta local de clientes y cambio de estado visual.
- Pantalla de conexión MikroTik preparada como placeholder.
- Flujo GitHub Actions para compilar un APK de depuración.

## Seguridad y limitaciones importantes
- Esta versión NO se conecta al CCR1036 y NO ejecuta comandos en el router.
- Los clientes de esta primera versión viven solo en memoria y se pierden al cerrar la app.
- No introducir contraseñas reales ni datos de abonados en esta versión.
- La integración real se hará después de definir acceso seguro, permisos mínimos y confirmación explícita de cada acción.

## Compilar APK desde GitHub
1. Sube el contenido de este proyecto al repositorio `Puntorojomanager`, conservando las carpetas.
2. Abre la pestaña **Actions** y ejecuta **Build Android APK** (o espera a que termine el flujo tras subir a `main`).
3. Abre la ejecución terminada, entra en **Artifacts** y descarga `PuntoRojoManager-debug`.
4. Extrae el ZIP descargado y abre `app-debug.apk` en Android.

Requiere JDK 17 y Gradle 8.9 para compilar localmente.
