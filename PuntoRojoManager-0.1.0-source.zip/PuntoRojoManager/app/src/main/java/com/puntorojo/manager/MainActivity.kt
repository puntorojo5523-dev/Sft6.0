package com.puntorojo.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import java.text.NumberFormat
import java.util.Locale

data class Customer(
    val id: Int,
    val name: String,
    val pppoe: String,
    val plan: String,
    val monthlyPrice: Int,
    val active: Boolean = true
)

class ManagerViewModel : ViewModel() {
    var customers by mutableStateOf(
        listOf(
            Customer(1, "Cliente de prueba", "prueba001", "20 MB", 1200),
            Customer(2, "Ejemplo PuntoRojo", "ejemplo002", "30 MB", 1400)
        )
    )
        private set

    fun addCustomer(name: String, pppoe: String, plan: String, price: Int) {
        customers = customers + Customer((customers.maxOfOrNull { it.id } ?: 0) + 1, name, pppoe, plan, price)
    }

    fun toggleCustomer(id: Int) {
        customers = customers.map { if (it.id == id) it.copy(active = !it.active) else it }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PuntoRojoApp() }
    }
}

@Composable
fun PuntoRojoApp(vm: ManagerViewModel = viewModel()) {
    var page by remember { mutableStateOf("Inicio") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFFE53935),
            secondary = androidx.compose.ui.graphics.Color(0xFFFF8A80),
            background = androidx.compose.ui.graphics.Color(0xFF101114),
            surface = androidx.compose.ui.graphics.Color(0xFF1B1D22)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    listOf("Inicio", "Clientes", "Router", "Ajustes").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Inicio" -> Icons.Default.Dashboard
                                        "Clientes" -> Icons.Default.People
                                        "Router" -> Icons.Default.Router
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            when (page) {
                "Inicio" -> HomeScreen(vm.customers, Modifier.padding(padding))
                "Clientes" -> CustomersScreen(vm, Modifier.padding(padding))
                "Router" -> RouterScreen(Modifier.padding(padding))
                else -> SettingsScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(customers: List<Customer>, modifier: Modifier = Modifier) {
    val active = customers.count { it.active }
    val billed = customers.sumOf { it.monthlyPrice }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("PUNTOROJO", color = MaterialTheme.colorScheme.primary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text("Manager", color = MaterialTheme.colorScheme.onBackground, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Panel de control", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Clientes", customers.size.toString(), Modifier.weight(1f))
            StatCard("Activos", active.toString(), Modifier.weight(1f))
        }
        StatCard("Facturación mensual estimada", money(billed), Modifier.fillMaxWidth())
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Estado del proyecto", fontWeight = FontWeight.Bold)
                Text("Versión inicial: modo local de demostración.")
                Text("Todavía no se conecta ni modifica tu MikroTik.", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f), fontSize = 13.sp)
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CustomersScreen(vm: ManagerViewModel, modifier: Modifier = Modifier) {
    var showAdd by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Clientes PPPoE", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            FilledTonalIconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Agregar") }
        }
        Text("Datos de demostración; aún no sincronizados con el router.", color = MaterialTheme.colorScheme.primary)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.customers, key = { it.id }) { c ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold)
                            Text("${c.pppoe} · ${c.plan}", fontSize = 13.sp)
                            Text(money(c.monthlyPrice), color = MaterialTheme.colorScheme.primary)
                        }
                        AssistChip(onClick = { vm.toggleCustomer(c.id) }, label = { Text(if (c.active) "Activo" else "Inactivo") })
                    }
                }
            }
        }
    }
    if (showAdd) AddCustomerDialog(
        onDismiss = { showAdd = false },
        onSave = { n, p, plan, price -> vm.addCustomer(n, p, plan, price); showAdd = false }
    )
}

@Composable
fun AddCustomerDialog(onDismiss: () -> Unit, onSave: (String, String, String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var pppoe by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf("30 MB") }
    var price by remember { mutableStateOf("1400") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo cliente") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre completo") }, singleLine = true)
                OutlinedTextField(pppoe, { pppoe = it }, label = { Text("Usuario PPPoE") }, singleLine = true)
                OutlinedTextField(plan, { plan = it }, label = { Text("Plan") }, singleLine = true)
                OutlinedTextField(price, { price = it }, label = { Text("Precio mensual (RD$)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && pppoe.isNotBlank() && (price.toIntOrNull() ?: 0) > 0,
                onClick = { onSave(name.trim(), pppoe.trim(), plan.trim(), price.toInt()) }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun RouterScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Conexión MikroTik", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CCR1036 · RouterOS 7", fontWeight = FontWeight.Bold)
                Text("Conexión: no configurada")
                Text("La aplicación no ejecutará cambios en el router en esta versión.")
            }
        }
        Text("Siguiente etapa", fontWeight = FontWeight.Bold)
        Text("Configurar acceso seguro por API-SSL o generar comandos revisables para copiar y pegar. Nunca guardes aquí la contraseña de administrador.")
    }
}

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ajustes", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("PuntoRojo Manager · 0.1.0")
        Text("Moneda: Peso dominicano (RD$)")
        Text("Los datos de esta versión son temporales y se reinician al cerrar la aplicación.")
        Text("Antes de usar con clientes reales se añadirá almacenamiento local seguro y copias de respaldo.")
    }
}

fun money(value: Int): String = NumberFormat.getCurrencyInstance(Locale("es", "DO")).format(value)
